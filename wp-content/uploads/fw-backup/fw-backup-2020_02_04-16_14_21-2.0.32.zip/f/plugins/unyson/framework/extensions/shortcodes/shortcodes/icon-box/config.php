<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Icon Box', 'fw'),
	'description'   => __('Add an Icon Box', 'fw'),
	'tab'           => __('Content Elements', 'fw')
);
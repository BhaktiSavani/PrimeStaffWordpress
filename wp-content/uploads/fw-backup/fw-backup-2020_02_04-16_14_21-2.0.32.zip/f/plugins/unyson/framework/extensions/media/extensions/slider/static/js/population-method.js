jQuery(document).ready(function($){
	$('.selectize').selectize();
});
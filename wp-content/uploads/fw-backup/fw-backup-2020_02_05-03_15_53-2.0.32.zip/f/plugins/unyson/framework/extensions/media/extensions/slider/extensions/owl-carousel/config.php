<?php if (!defined('FW')) die('Forbidden');
$cfg['multimedia_types'] = array('video');

<?php if (!defined('FW')) die('Forbidden');

require dirname(__FILE__) . '/base/class-fw-slider.php';

class FW_Extension_Slider_Default extends FW_Slider
{
	/**
	 * @internal
	 */
	public function _init()
	{
	}
}
<?php if (!defined('FW')) die('Forbidden');

$manifest['name']        = __( 'Population Method - Categories', 'fw' );
$manifest['description'] = __( 'Population Method - Categories', 'fw' );

$manifest['version'] = '1.0.0';

$manifest['display'] = 'slider';